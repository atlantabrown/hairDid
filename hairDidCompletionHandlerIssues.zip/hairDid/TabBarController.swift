//
//  TabBarController.swift
//  hairDid
//
//  Created by Atlanta Brown on 11/19/21.
//

import UIKit
import Firebase

class User {
    var accountType: String = ""
}

//let semaphore = DispatchSemaphore(value: 0)
var userIsClient:Bool = false

class TabBarController: UITabBarController, UITabBarControllerDelegate {
    override func viewDidLoad() {
        super.viewDidLoad()
        delegate = self
    }
    

    
    
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
        
        
//            fetchUserType() {
//                userIsClient in
//                self.userIsClient = userIsClient
//                print("user is client?: \(userIsClient)")
//                print("sel \(self.userIsClient)")
//            }
//        fetchUserType { Bool in
//
//        }
        
//        fetchUserType() { (userIsClient) in
//            self.userIsClient = userIsClient
//            print("need to work: \(self.userIsClient)")
//            print("another try: \(userIsClient)")
//            //semaphore.signal()
//        }
        fetchUserType()
        //sleep(3)
        print("userIsclient self: \(userIsClient)")
        
       
        
        //why does this happen first
        happenLaterPls()
    }
    
    func happenLaterPls(){
        //why does this happen first
        //semaphore.wait()
        print("user is client?: outside self \(userIsClient)")
        print("user is client?: outside normie \(userIsClient)")
        
        let item1 = (userIsClient) ? ClientHomePageVC() : ProviderHomePageVC()
        let icon1 = UITabBarItem(title: "Home", image: UIImage(systemName: "house"), selectedImage: UIImage(systemName: "house.fill"))
        item1.tabBarItem = icon1
        
        print("HERE")
        
        let item2 = SettingsVC()
        let icon2 = UITabBarItem(title: "Settings", image: UIImage(systemName: "gearshape"), selectedImage: UIImage(systemName: "gearshape.fill"))
        item2.tabBarItem = icon2
        
        let controllers = [item1, item2]
        self.viewControllers = controllers
    }
    
    //userCompletionHandler: @escaping (Bool) -> Void
    func fetchUserType() {
        let user = Auth.auth().currentUser
        let uid = user!.uid
        var accountType = ""
        let ref = Database.database().reference()
        print("IN FETCH USERTYPE")
        ref.child("users/\(uid)/accountType").getData(completion:  { error, snapshot in
          guard error == nil else {
            print(error!.localizedDescription)
            return
          } ///get data is async
          accountType = snapshot.value as? String ?? "Unknown"
            
            userIsClient = (accountType == "client")
            print("acct type = client: \((accountType == "client"))")
            print("userIsClient inside fetch: \(userIsClient)")

            //userCompletionHandler(userIsClient)
        })
    }

    //Delegate methods
    func tabBarController(_ tabBarController: UITabBarController, shouldSelect viewController: UIViewController) -> Bool {
        return true;
    }
}
